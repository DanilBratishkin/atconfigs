# danilbratishkin_configs-fuzion

Откройте терминал и пропишите ` ./install.sh `
